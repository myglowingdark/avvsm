<?php $__env->startSection('title', 'View Transaction'); ?>
<?php $__env->startSection('parent-page', 'Wallet '); ?>
<?php $__env->startSection('page', 'View Transaction'); ?>
<?php $__env->startSection("adminform-content"); ?>


<div class="card">
                <!-- <h5 class="card-header">View Enquiry Students List</h5> -->
                
                <div class="card-body">
                  <div class="table-responsive text-nowrap">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th></th>
                          
                          <th></th>
                          <th></th>
                         
                          <th></th>
                          <th></th>
                          <th></th>
                         

                          <th></th>
                          
                         
                          <th></th>
                          <th></th>
                          
                        
                        </tr>
                      </thead>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/adminform", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kavita\Documents\GitHub\ABVSSM\avvsm\resources\views/admin/view-transaction.blade.php ENDPATH**/ ?>