<?php $__env->startSection('title', ' Franchise List'); ?>
<?php $__env->startSection('parent-page', 'Franchise Management'); ?>
<?php $__env->startSection('page', ' Franchise List'); ?>
<?php $__env->startSection("adminform-content"); ?>


<div class="card">
<div class="row align-items-center">
        <div class="col">
            <h5 class="card-header">Franchise List</h5>
        </div>
        <div class="col text-right" style="margin-left: 800px;">
            <a href=""  class="btn btn-primary" fdprocessedid="pnohgn" >Add Franchise</a>
        </div>
    </div>
                <div class="card-body">
                  <div class="table-responsive text-nowrap">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Franchise id</th>
                          <th>Owner Name</th>
                          <th>State</th>
                          <!-- <th>Candidate Image</th> -->
                          <th>Address</th>
                          <th>Adhar Card No</th>
                          <th>Pan Card No</th>
                          <!-- <th> Action</th> -->

                          <th>Center Address</th>
                          
                          <!-- <th>Export</th> -->
                          <!-- <th>Status</th> -->
                          <th>Center Contact No</th>
                          <th>Tenure</th>
                          <th>Adhar Card Image</th>
                          <th>Signature</th>
                          <th>Pan Card No</th>
                          <th>Pan Card</th>
                          
                          <th>Passport Photo</th>
                          <!-- <th>Action</th> -->
                        </tr>
                      </thead>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/adminform", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kavita\Documents\GitHub\ABVSSM\avvsm\resources\views/admin/franchise-list.blade.php ENDPATH**/ ?>