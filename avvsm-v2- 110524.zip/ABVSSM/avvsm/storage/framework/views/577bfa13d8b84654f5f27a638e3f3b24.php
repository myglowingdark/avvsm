<?php $__env->startSection('title', ' Franchise List'); ?>
<?php $__env->startSection('parent-page', 'Franchise Management'); ?>
<?php $__env->startSection('page', ' Franchise List'); ?>
<?php $__env->startSection("adminform-content"); ?>


<div class="card">
<div class="row align-items-center">
        <div class="col">
            <h5 class="card-header">Franchise List</h5>
        </div>
        <div class="col text-right">
        <div class="d-flex justify-content-end align-items-center">
    <a href="<?php echo e(route('create-franchise'), false); ?>" class="btn btn-primary" style="margin-right: 10px;" fdprocessedid="pnohgn">Add Franchise</a>
    <button type="button" id="exportdata" class="btn btn-primary" style="display:none;"onclick="exportToExcel()">Export Selected Data</button>
</div>
        </div>
    </div>      
                
    <!-- <div class="card-body" style="display: flex; justify-content: flex-start; margin-bottom: 10px;">
    <button type="button" id="exportdata" class="btn btn-lg btn-primary" onclick="exportToExcel()" style="display: none;">Export Selected Data</button>
  
</div> -->
                <div class="card-body">
                  <div class="table-responsive text-nowrap">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Sr.no</th>
                          <th>Profile</th>
                          <th>Franchise id</th>
                          <td>Email</td>
                          <th>Owner Name</th>
                          <th>State</th>
                          <th>Documents</th>
                          <th>Tenure</th>                     

                          
                          <th>Center Address</th>                     

                          <th>Action</th>
                          <th>
                                Select All
                                <label>
                                <input type="checkbox" id="selectAllCheckbox" onchange="toggleSelectAll()">    
                                </label>
                            </th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $franchises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $franchise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($franchise->id, false); ?></td>
                                <td>

                                    <img src="<?php echo e(asset( $franchise->passport_photo), false); ?>" alt="" class="img-fluid thumbnail" width="100px" height="100px">
                                <td><?php echo e($franchise->franchise_id, false); ?></td>

                                <!-- <td><?php echo e($franchise->franchise_id, false); ?></td> -->
                                <td><?php echo e(optional($franchise->user)->email, false); ?></td>
                                <td><?php echo e($franchise->owner_name, false); ?></td>
                                <td><?php echo e($franchise->state, false); ?></td>
                                <td>
                                  <a href="<?php echo e(asset($franchise->adhar_card), false); ?>" target="blank"><span class="badge bg-label-success">Adhar Card</span></a><br>
                                <a href="<?php echo e(asset($franchise->pan_card ), false); ?>" target="blank"><span class="badge bg-label-primary">Pan Card</span></a><br>
                                <a href="<?php echo e(asset($franchise->signature), false); ?>" target="blank"><span class="badge bg-label-warning">Signature</span></a>
                              </td>
                                <!-- <td><?php echo e($franchise->center_address, false); ?></td> -->

                                <!-- <td><?php echo e($franchise->center_contact_no, false); ?></td> -->

                                <td><?php echo e($franchise->tenure, false); ?></td>
                                <td>
                                  <!-- <a class="mx-2" href="javascript:void(0);"><i class="bx bx-show me-1"></i></a> -->
                                    <a href="<?php echo e(route('edit-franchise',['id' => $franchise->id ]), false); ?>" class="mx-2"><i class="bx bx-edit-alt me-1"></i></a>    
                                    <a href="<?php echo e(route('delete-franchise',['id' => $franchise->id ]), false); ?>" class="mx-2 delete-franchise"><i class="bx bx-trash me-1"></i></a>    
                                </td>

                                
                               <td><input type="checkbox" onchange="toggleButtons()"></td>


                                <td><?php echo e($franchise-> owner_name, false); ?></td>
                                <td><?php echo e($franchise->state, false); ?></td>
                                
                                <td>
                                  <a href="/<?php echo e($franchise->adhar_card, false); ?>" target="blank"><span class="badge bg-label-success">Adhar Card</span></a><br>
                                <a href="/<?php echo e($franchise->pan_card, false); ?>" target="blank"><span class="badge bg-label-primary">Pan Card</span></a><br>
                                <a href="/<?php echo e($franchise->signature, false); ?>" target="blank"><span class="badge bg-label-warning">Signature</span></a></td>
                                <td><?php echo e($franchise->center_address, false); ?></td>
                                <td>
                                  <div style = "">
                                  <a class="mx-2" href="javascript:void(0);"><i class="bx bx-show me-1"></i></a>
                                    <a class="mx-2" href="javascript:void(0);"><i class="bx bx-edit-alt me-1"></i></a>
                                    <a class="mx-2" href="javascript:void(0);"><i class="bx bx-trash me-1"></i></a>
                                  </div> 
                                   </td>
                                   <td><input type="checkbox" onchange="toggleButtons()"></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>

                      <script>

                        

  function exportToExcel() {
    // Logic to gather selected data and export to Excel
    var selectedRows = [];
    var checkboxes = document.querySelectorAll('tbody input[type="checkbox"]:checked');

    checkboxes.forEach(function(checkbox) {
      var rowData = [];
      var row = checkbox.closest('tr');
      row.querySelectorAll('td').forEach(function(cell) {
        rowData.push(cell.innerText);
      });
      selectedRows.push(rowData.join('\t')); // Tab-separated values for Excel
    });

    // Prepare data for download
    var data = selectedRows.join('\n'); // New line for each row
    var blob = new Blob([data], { type: 'text/plain' });
    var url = URL.createObjectURL(blob);

    // Trigger download
    var link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'selected_data.xls');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  function toggleSelectAll() {
    var selectAllCheckbox = document.getElementById('selectAllCheckbox');
    var checkboxes = document.querySelectorAll('tbody input[type="checkbox"]');

    checkboxes.forEach(function(checkbox) {
      checkbox.checked = selectAllCheckbox.checked;
    });

    toggleButtons(); // Update buttons based on the state of "Select All" checkbox
  }

  function toggleButtons() {
    var checkboxes = document.querySelectorAll('tbody input[type="checkbox"]');
    var anyChecked = false;

    checkboxes.forEach(function(checkbox) {
      if (checkbox.checked) {
        anyChecked = true;
      }
    });

    var exportButton = document.getElementById('exportdata');

    if (anyChecked) {
      exportButton.style.display = 'block';
    } else {
      exportButton.style.display = 'none';
    }
  }



document.addEventListener('DOMContentLoaded', function() {
  // Find all delete-franchise links
  var deleteLinks = document.querySelectorAll('.delete-franchise');

                            // Attach click event listener to each delete link
                            deleteLinks.forEach(function(link) {
                                link.addEventListener('click', function(event) {
                                    // Prevent the default action (i.e., following the link)
                                    event.preventDefault();

                                    // Get the franchise ID from data attribute
                                    var franchiseId = this.getAttribute('data-franchise-id');

                                    // Show confirmation dialog
                                    var confirmDelete = confirm('It will delete permanently. Are you sure you want to delete this franchise? ');

                                    // If user confirms deletion, redirect to the delete URL
                                    if (confirmDelete) {
                                        window.location.href = this.href;
                                    }
                                });
                            });
                        });
                    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/adminform", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kavita\Documents\GitHub\ABVSSM\avvsm\resources\views/admin/manage-franchise.blade.php ENDPATH**/ ?>