<?php $__env->startSection("content"); ?>
<!-- Menu -->

  <!-- aside -->
  <?php echo $__env->make("adminsidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- / Menu -->

  <!-- Layout container -->

  <div class="layout-page">
      <?php echo $__env->make("navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
   
  <!-- / Navbar -->
      <!-- Content wrapper -->
      <div class="content-wrapper">
          <div class="container-xxl flex-grow-1 container-p-y">
          <!-- Content -->
          <?php echo $__env->yieldContent("admincontent"); ?>
      </div>
  
  </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make("dashboard", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kavita\Documents\GitHub\ABVSSM\avvsm\resources\views/admin.blade.php ENDPATH**/ ?>