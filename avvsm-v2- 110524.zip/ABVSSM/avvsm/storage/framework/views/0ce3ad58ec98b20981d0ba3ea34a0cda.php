<?php $__env->startSection('title', 'View Student'); ?>
<?php $__env->startSection('parent-page', 'Student Management'); ?>
<?php $__env->startSection('page', 'View Student'); ?>
<?php $__env->startSection("adminform-content"); ?>


<div class="card">
                <!-- <h5 class="card-header">View Enquiry Students List</h5> -->
                <div>
                <button type="button" class="btn btn-lg btn-primary" fdprocessedid="fdyzc7" onclick="exportToExcel()"  style="display:none;">Enquiry Form Export</button>
                </div>
                <div class="card-body">
                  <div class="table-responsive text-nowrap">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Sr.No</th>
                          
                          <th>Counselor Name</th>
                          <th>Candidate Name</th>
                          <!-- <th>Candidate Image</th> -->
                          <th>Contact No</th>
                          <th>Interested Course</th>
                          <th>Suggested Course</th>
                          <!-- <th> Action</th> -->

                          <th>Admission</th>
                          
                          <!-- <th>Export</th> -->
                          <!-- <th>Status</th> -->
                          <th>Export <label>  
                            
                           <input type="checkbox" onclick="selectAll()">
       
                          </label></th>
                          <th>Action</th>
                        </tr>
                      </thead>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/adminform", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kavita\Documents\GitHub\ABVSSM\avvsm\resources\views/admin/view-student-enquiry-list.blade.php ENDPATH**/ ?>