<?php $__env->startSection('title', 'View Student'); ?>
<?php $__env->startSection('parent-page', 'Student Management'); ?>
<?php $__env->startSection('page', 'View Student'); ?>
<?php $__env->startSection("adminform-content"); ?>


<div class="card">
<div class="row align-items-center">
        <div class="col">
            <h5 class="card-header">Student List</h5>
        </div>
        <div class="col text-right">
        <div class="d-flex justify-content-end align-items-center">
    <a href="<?php echo e(route('add-new-student'), false); ?>" class="btn btn-primary" style="margin-right: 10px;" fdprocessedid="pnohgn">Add Student</a>
    <button type="button" id="exportdata" class="btn btn-primary" onclick="exportToExcel()" style="display:none;">Export Selected Data</button>
</div>
        </div>
    </div>    
                <div class="card-body">
                  <div class="table-responsive text-nowrap">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          
                        <th>Profile Photo</th>
                          <th>Student id</th>
                          
                          <th>Center</th>
                          <th>Year</th>
                          
                          <th>Student Name</th>
                          <th>Father Name</th>
                          <th>Contact No</th>
                          <th>Gender</th>
                          <th>Email</th>
                          <th>marital status</th>
                          <th>Course Name</th>
                          <th>Course Duration</th>
                          <th>Date Of Birth</th>
                          <th>State</th>
                          <th>District</th>
                          <th>Date of Admission</th>
                          <!-- <th>Action</th> -->
                          <th>
                                Select All
                                <label>
                                <input type="checkbox" id="selectAllCheckbox" onchange="toggleSelectAll()">    
                                </label>
                            </th>
                          <!-- <th>Action</th> -->
                        </tr>
                      </thead>
                      <tbody>
                   <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    
                   <td><img src="<?php echo e(asset( $s->profile_photo), false); ?>" alt="" class="img-fluid thumbnail" width="100px" height="100px"></td>
                       <td><?php echo e($s->student_id, false); ?></td>
                       <td><?php echo e($s->center, false); ?></td>
                       <td><?php echo e($s->year, false); ?></td>
                       <td><?php echo e($s->student_name, false); ?></td>
                       <td><?php echo e($s->father_name, false); ?></td>
                       <td><?php echo e($s->contact_no, false); ?></td>
                       <td><?php echo e($s->gender, false); ?></td>
                       <td><?php echo e($s->email, false); ?></td>
                       <td><?php echo e($s->marital_status, false); ?></td>
                       <td><?php echo e($s->course->course_name, false); ?></td>
                       <td><?php echo e($s->course_duration, false); ?></td>
                       <td><?php echo e($s->date_of_birth, false); ?></td>
                       <td><?php echo e($s->state, false); ?></td>
                       <td><?php echo e($s->district, false); ?></td>
                       <td><?php echo e($s->date_of_admission, false); ?></td>
                       
                      
                       <!-- <td>
                             <div style = "">
                             <a class="mx-2"  href="javascript:void(0);"><i class="bx bx-show me-1"></i></a>
                               <a class="mx-2" href="javascript:void(0);"><i class="bx bx-edit-alt me-1"></i></a>
                               <a class="mx-2"   href="<?php echo e(route('delete-student',['id' => $s->id ]), false); ?>"><i class="bx bx-trash me-1"></i></a>
                             </div> 
                              </td> -->
                    <td><input type="checkbox" onchange="toggleButtons()"></td>
                      
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
               </tbody>
               <script>
 function exportToExcel() {
   // Logic to gather selected data and export to Excel
   var selectedRows = [];
   var checkboxes = document.querySelectorAll('tbody input[type="checkbox"]:checked');

   checkboxes.forEach(function(checkbox) {
     var rowData = [];
     var row = checkbox.closest('tr');
     row.querySelectorAll('td').forEach(function(cell) {
       rowData.push(cell.innerText);
     });
     selectedRows.push(rowData.join('\t')); // Tab-separated values for Excel
   });

   // Prepare data for download
   var data = selectedRows.join('\n'); // New line for each row
   var blob = new Blob([data], { type: 'text/plain' });
   var url = URL.createObjectURL(blob);

   // Trigger download
   var link = document.createElement('a');
   link.setAttribute('href', url);
   link.setAttribute('download', 'selected_data.xls');
   link.style.visibility = 'hidden';
   document.body.appendChild(link);
   link.click();
   document.body.removeChild(link);
 }

 function toggleSelectAll() {
   var selectAllCheckbox = document.getElementById('selectAllCheckbox');
   var checkboxes = document.querySelectorAll('tbody input[type="checkbox"]');

   checkboxes.forEach(function(checkbox) {
     checkbox.checked = selectAllCheckbox.checked;
   });

   toggleButtons(); // Update buttons based on the state of "Select All" checkbox
 }

 function toggleButtons() {
   var checkboxes = document.querySelectorAll('tbody input[type="checkbox"]');
   var anyChecked = false;

   checkboxes.forEach(function(checkbox) {
     if (checkbox.checked) {
       anyChecked = true;
     }
   });

   var exportButton = document.getElementById('exportdata');

   if (anyChecked) {
     exportButton.style.display = 'block';
   } else {
     exportButton.style.display = 'none';
   }
 }
</script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin/adminform", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kavita\Documents\GitHub\ABVSSM\avvsm\resources\views/admin/view-student-list.blade.php ENDPATH**/ ?>