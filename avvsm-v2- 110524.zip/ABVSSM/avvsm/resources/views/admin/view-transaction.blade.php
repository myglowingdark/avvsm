@extends("admin/adminform")
@section('title', 'View Transaction')
@section('parent-page', 'Wallet ')
@section('page', 'View Transaction')
@section("adminform-content")


<div class="card">
                <!-- <h5 class="card-header">View Enquiry Students List</h5> -->
                
                <div class="card-body">
                  <div class="table-responsive text-nowrap">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th></th>
                          
                          <th></th>
                          <th></th>
                         
                          <th></th>
                          <th></th>
                          <th></th>
                         

                          <th></th>
                          
                         
                          <th></th>
                          <th></th>
                          
                        
                        </tr>
                      </thead>


@endsection